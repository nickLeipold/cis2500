#include <stdlib.h>
#include <string.h>
#include <curses.h>
#include <time.h>
#include "room.h"
#include "game.h"

void drawRooms(ItLoc * items)
{
  int i;
  int j;
  int rmCount;
  int maxY;
  int maxX;
  int maxRmY;
  int plrX;
  int plrY;

  srand(time(NULL));
  plrX = 0;
  plrY = 0;
  rmCount =0;
  maxRmY = 0;

  initscr(); //initialize ncurses
  noecho();

  getmaxyx(stdscr,maxY,maxX);
  if(maxY < 40  || maxX < 78) //set the minumum screen size
  {
    mvprintw(3,3,"sceen is too small");
    getch();
    endwin();
    free(items);
    return;
  }

  mvprintw(3,3,"Max screen is %d : %d \n", maxX, maxY);
  getch();
  erase();
  move(0,0);

  for(i=0;i<= items[0].numRoom;i++)
  {
    for( j = 0; j< items[i].numInst; j++)
    {
      if((items[i].desc[j]) == '@') //finds where the player is
      {
        plrX = items[i].x[j];
        plrY = items[i].y[j];
      }
    }

    if(items[i].desc[0] == 'X')//the first index is the dimensions of the room denoted by 'X'
    {
      roomArray(items[i].y[0] +1 ,items[i].x[0] +1 ,items[i]);
      move(getcury(stdscr) - items[i].y[0],getcurx(stdscr)+2);
      if(maxRmY < items[i].y[0])
      {
        maxRmY = items[i].y[0];
      }

    }
    rmCount++;
    if(rmCount == 3)
    {
      move(getcury(stdscr) + maxRmY +2,0);//sets where the 4th room will be drawn
      //rmCount =0;

    }
}
  move(plrY +1,plrX+1);
  refresh();
  free(items);
  gameLoop(getcury(stdscr),getcurx(stdscr));



}

void roomArray(int height, int width, ItLoc items)
{
  char room[height +1][width+1]; //make an array the size of the room one bigger in both dimensions for walls
  int currentX;
  int currentY;
  int i;
  int j;
  i=0;
  j=0;

  for(i=0; i<=height;i++) //draws a room the size desired with the walls
  {
    for(j=0; j<=width;j++)
    {
      room[i][j] = '.';

      if((i==0) || (i == height))
      {
        room[i][j] = '_';
      }
      else if((j==0) || (j== width))
      {
        room[i][j] = '|';
      }
    }
  }

  for(i=1;i<items.numInst; i++) //gets all doors in the right positions
  {
    if(items.y[i] == 99)
    {
      items.y[i] = height-1;
    }
    if(items.x[i] == 99)
    {
      items.x[i] = width -1;
    }
    room[items.y[i]+1][items.x[i]+1] = items.desc[i];

  }


  for(i=0;i<=height;i++)  //prints the room
  {
    for(j=0;j<=width;j++)
    {
      printw("%c", room[i][j]);
    }
    currentY = getcury(stdscr);
    currentX = getcurx(stdscr);
    move(currentY+1,currentX - width-1); //resets the cursor at the edge of the room
  }
  move(currentY -1,currentX );

}

void gameLoop(int curY, int curX)
{
  char input;
  int gold;
  int stairs;
  gold =0;
  stairs = 0;

  input = getch();
  while((input != 'q') && (stairs != 1))
  {
    //refresh();
    moveChar(input, curY, curX, &gold, &stairs);
    curY = getcury(stdscr);
    curX = getcurx(stdscr);
    input = getch();
    //refresh();
  }

  getch();
  endGame(gold);

}

void moveChar(char key, int curY, int curX, int * gold, int * stairs)
{

  switch(key)
  {
    case 'a':
      updateScreen(curY, curX-1 , gold, stairs);
      break;

    case 'w':
      updateScreen(curY-1, curX, gold ,stairs);
      break;

    case 's':
      updateScreen(curY +1, curX, gold ,stairs);
      break;

    case 'd':
      updateScreen(curY, curX +1, gold, stairs);
      break;
  }
}

void updateScreen(int updateY, int updateX, int * gold, int * stairs)
{
  if (hitDetect(updateY, updateX, gold, stairs) >= 1)  //altered from lab session, sorry about similarity if it is a problem, was the best way to do it i felt, also made another value it can detect
  {

    if(hitDetect(updateY, updateX, gold, stairs) ==2)
    {
      printw( "+");
    }
    else
    {
      printw(".");
    }
    mvprintw(updateY, updateX, "@");
    move(updateY, updateX);
    
  }
}

int hitDetect(int toGoY, int toGoX, int * gold, int * stairs)
{
  int curX = getcurx(stdscr);
  int curY = getcury(stdscr);

  int r;

  char value = (char)mvinch(toGoY, toGoX);//gets character of the position wanting to move to
  move(curY, curX);
  if((value == '+'))
  {
    return 2;
  }
  if((value == '>') || (value == '<'))
  {
    *stairs =1;
  }
  if((value == '*'))//small gold
  {
    r = (rand()%50) +1;
    *gold +=r;//update gold value
  }
  if((value == '8'))//big gold
  {
    r = (rand()%200) +50;
    *gold += r;
  }
  if((value == '_') || (value == '|') || (value == 'Z') || (value == 'A') || (value == 'B') || (value == 'S'))
  {
    return 0;
  }
  return 1;
}

void endGame(int gold)
{
  erase();
  mvprintw(3,3,"gold collected %d", gold);
  getch();
  endwin();
}
