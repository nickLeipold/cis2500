#ifndef __NLEIPOLD_GAME_H__
#define __NLEIPOLD_GAME_H__

/*drawRooms
 * IN: item and room struct
 * OUT:
 * ERROR:
 */
void drawRooms(ItLoc * items);

/*roomArray
 * IN: room dimensions, item locations
 * OUT: character array
 * ERROR:
 */
void roomArray(int height, int width, ItLoc  items);

/*gameLoop
 * loops through the game ever time the player presses and updates locations
 * IN: the players current location, the key pressed
 * OUT:
 * ERROR:
 */
void gameLoop(int curY, int curX);

/*endGame
 * stops ncurses and prints value of gold collected
 * IN: ammount of gold
 * OUT: --------------
 * ERROR: --------------
 */
void endGame(int gold);

/*moveChar
 * checks as to which key was pressed
 * IN: current x and y position and the pressed key, gold pointer and stairs pointer
 * OUT: nothing
 * ERROR: ---------------
 */
void moveChar(char key, int curY, int curX, int * gold, int * stairs);

/*updateScreen
 * if the hit detection is false then it will overwrite old space and place character in new space
 * IN: the place where you want to move, gold pointer and stairs pointer
 * OUT: nothing
 * ERROR: -----------
 */
void updateScreen(int updateY, int updateX, int * gold, int * stairs);

/*hitDetect
 * checks to see if the desired move location is available for move
 * IN: the x and y where you want to move, gold pointer and stairs pointer
 * OUT: returns 1, 2 or 0
 * ERROR:--------------
 */
int hitDetect(int toGoY, int toGoX, int * gold, int * stairs);




#endif

