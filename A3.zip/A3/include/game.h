#ifndef __NLEIPOLD_GAME_H__
#define __NLEIPOLD_GAME_H__


/*plyrStruct
 * stores the players position and items stored as well as other stats
 */
struct plyrStruct
{
  int x;
  int y;
  char bag[5]; //can have 5 items stored
  int equipVal[5];
  int potionNum;
  int itemNum;
  int attack;
  int maxHp;
  int curHp;
  int gold;
  int doorFlag;
  int hallway;
};

typedef struct plyrStruct PlyrStruct;

/*enemy
 * the stats of the enemies with their locations and stats
 */
struct enemy
{
  int x;
  int y;
  char desc; 
  char move[5];
  int moveNum;
  int attack;
  int speed;
  int health;
};

typedef struct enemy Enemy;

/*drawRooms
 * IN: item and room struct
 * OUT:
 * ERROR:
 */
void drawRooms(ItLoc * items);

/*roomArray
 * IN: room dimensions, item locations
 * OUT: character array
 * ERROR:
 */
void roomArray(ItLoc * items);

/*drawHallways
 *takes in the max room height, item struct and room array using these values it will draw the hallways
 *IN:
 *OUT:
 *ERROR: ----------
 */
void drawHallways(int maxRmY,int y, int x, char dir);

/*gameLoop
 * loops through the game ever time the player presses and updates locations
 * IN: the players current location, the key pressed
 * OUT:
 * ERROR:
 */
void gameLoop(int curY, int curX, Enemy * enemies);

/*statusUpdate
 * takes in the player struct and prints the updated stats
 * IN: PlyrStruct, y and x location
 * OUT: prints stats to the ncurses screen
 * ERROR: -------
 */
void statusUpdate(PlyrStruct p, int y, int x);

/*endGame
 * stops ncurses and prints value of gold and other items collected
 * IN: player struct
 * OUT: --------------
 * ERROR: --------------
 */
void endGame(PlyrStruct p);

/*moveChar
 * checks as to which key was pressed
 * IN: current x and y position and the pressed key, gold pointer and stairs pointer
 * OUT: nothing
 * ERROR: ---------------
 */
void moveChar(char key, int curY, int curX, PlyrStruct * p, int * flag, Enemy * enemies);

/*updateScreen
 * if the hit detection is false then it will overwrite old space and place character in new space
 * IN: the place where you want to move, gold pointer and stairs pointer
 * OUT: nothing
 * ERROR: -----------
 */
void updateScreen(int updateY, int updateX, PlyrStruct * p, int * flag,Enemy * enemies);

/*hitDetect
 * checks to see if the desired move location is available for move
 * IN: the x and y where you want to move, gold pointer and stairs pointer
 * OUT: returns 1, 2 or 0
 * ERROR:--------------
 */
int hitDetect(int toGoY, int toGoX, PlyrStruct * p, int * flag, Enemy * enemies);

/*createPlayer
 *takes the player struct pointer
 *IN: player struct pointer
 *OUT: the edited struct pointer
 *ERROR: -------
 */
void createPlayer(PlyrStruct * p);

/*createEnemy
 *takes in the enemy struct, the index and sets values for the enemy types
 *IN: enemy struct, enemy struct index
 *OUT: the values of the enemies stats
 *ERROR: ------
 */
void createEnemy(Enemy * e, int index);
/*useItem
 *takes in the key pressed, the current player position and the player stats
 *IN: input char, y position and x position, player stats struct
 *OUT: will change player stats values but does not return
 *ERROR: ------
 */
void useItem(char in,int curY,int curX,PlyrStruct * p);

/*combat
 *takes in the the enemy and player and runs a combat sequence based on their stats, if enemy dies the function returns 1
 *IN: enemy, hero struct, current y and x positions
 *OUT: 0 if the enemy is not killed, 1 if the enemy is killed
 *ERROR: -------
 */
int combat(Enemy * e, int index,PlyrStruct * p, int y, int x);

/*moveEnemies
 *takes in the enemy structs and then moves them based on their route
 *IN: enemy structs, player x and y
 *OUT: nothing, moves enemies only
 *ERROR: -------
 */
void moveEnemies(Enemy * e, int y, int x);

 
#endif

