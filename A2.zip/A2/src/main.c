#include <stdlib.h>
#include <stdio.h>
#include "room.h"
#include "game.h"

int main(int argc, char * argv[])
{
  if(argc != 2)
  {
    printf("incorrect number of arguments\n");
    return 1;
  }
  ItLoc * items;
  items = parceFile(argv[1]);
  drawRooms(items);

  return 0;
}
