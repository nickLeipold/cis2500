#include <stdlib.h>
#include <string.h>
#include <curses.h>
#include <time.h>
#include "room.h"
#include "game.h"

void drawRooms(ItLoc * items)
{
  int maxY;
  int maxX;
  
  srand(time(NULL));
  
  initscr(); //initialize ncurses
  noecho();

  getmaxyx(stdscr,maxY,maxX);
  if(maxY < 48  || maxX < 78) //set the minumum screen size
  {
    mvprintw(3,3,"sceen is too small");
    getch();
    endwin();
    free(items);
    return;
  }

  mvprintw(3,3,"Max screen is %d : %d \n", maxX, maxY);
  getch();
  erase();
  move(0,0);

  roomArray(items);
  Enemy * enemies = malloc(sizeof(Enemy)*50);
  for(int i=0;i<50;i++)
  {
    Enemy e = {0};
    enemies[i] = e;
  }
  
  int k;
  k=0;
  for(int i=0; i<6;i++)
  {
    for(int j=0; j<items[i].numInst; j++)
    {
      if(items[i].desc[j] == 'T' || items[i].desc[j] == 'B' ||items[i].desc[j] == 'A' ||items[i].desc[j] == 'Z' ||items[i].desc[j] == 'S')//loops through the items to find the enemies
      {
        enemies[k].desc = items[i].desc[j];// get the enemies all stored with stats
        enemies[k].x = items[i].x[j]+4; //+4 accounts for the room offset
        enemies[k].y = items[i].y[j]+4;
        createEnemy(enemies, k);
        k++;
        
      }
      
    }
  }
  
  refresh();
  free(items);
  gameLoop(getcury(stdscr),getcurx(stdscr), enemies);

  free(enemies);

}

void roomArray(ItLoc * items)
{
  char room[48][78]; //make an array the size of the room one bigger in both dimensions for walls
  memset(room, ' ', sizeof(room[0][0])*48*78);
  int offSetX;
  int offSetY;
  int roomWidth;
  int maxRmY;
  
  int plrX;
  int plrY;
  int i;
  int j;
  offSetX = 0;
  offSetY = 0;
  roomWidth =0;
  i=0;
  j=0;
  move(1,2);
  
  for(i =0; i<6; i++)
  {
    for(j= 0; j<=items[i].y[0]+1;j++) //creates the room in a 2d array
    {
      for(int k=0; k<=items[i].x[0]+1;k++)
      {
        room[j+offSetY][k+offSetX] = '.';

        if((j==0) || (j == items[i].y[0]+1))
        {
          room[j+offSetY][k+offSetX] = '-';
        }
        else if((k==0) || (k== items[i].x[0]+1))
        {
          room[j+offSetY][k+offSetX] = '|';
        }

        for(int l=1; l<items[i].numInst ; l++) //places the items in their locations
        {
          if((items[i].x[l]  == k-1 ) && (items[i].y[l]  == j-1))
          {
            items[i].y[l] = (j+offSetY)-1; //sets the locations of the items in the items struct
            items[i].x[l] = (k+offSetX)-1;
            room[j+offSetY][k+offSetX] = items[i].desc[l];
            //fprintf(stderr, "%d:y , %d:x, %c:char \n",items[i].y[l],items[i].x[l], room[j+offSetY][k+offSetX]);//prints to the error screen******************************************
          }
        }
      }
      
      if(maxRmY < items[i].y[0]) //sets the height where the 4th room will be drawn
      {
        maxRmY = items[i].y[0] +3;
      }

    }
    roomWidth = items[i].x[0] +6;
    if(i ==2) //increases the offset for the rooms to be drawn properly
    {
      offSetY = maxRmY +3;
      roomWidth = 0;
      offSetX=0;
    }
    offSetX+=roomWidth;
 }

 for(int i=0;i<40; i++)
 {
    for(j=0;j<70; j++)  //prints the room
    {
      if(room[i][j] == '@') //finds where the player is
      {
        plrX = getcurx(stdscr);
        plrY = getcury(stdscr);
      }

      mvprintw(i+3,j+3,"%c", room[i][j]); //prints the room 3 over and 3 down from corner
    }
  }
  for(int i=0; i<6;i++)
  {
    for(int j=0; j<items[i].numInst; j++)
    {

      if(items[i].desc[j] == '+')
      {
            items[i].x[j]+=4;
            items[i].y[j]+=4;//impliment the door to find the other hallways ********************************************************************
      }
    }
  }
  
  for(int i=0; i<6;i++)
  {
    for(int j=0; j<items[i].numInst; j++) //cycles through all the doors
    {
      if(items[i].desc[j] == '+')
      {   
        drawHallways(maxRmY, items[i].y[j], items[i].x[j], 0);
      }
    }
  }
  move(plrY,plrX);
}
void drawHallways(int maxRmY,int y, int x,char dir) //called recursively
{
  if((mvinch(y+1,x) == '#' && (dir != 's')) ||(mvinch(y-1,x) == '#' && (dir != 'n')))
  {
    return ; 
  }

  for(int i=0;i<78;i++) //draws centre hallway
  {
    mvprintw(maxRmY,i,"#");
  }
  
  if((mvinch(y+1,x) == ' ') && ((y<maxRmY) || dir == 0 ))
  {
    y++;
    mvprintw(y,x,"#");
    drawHallways(maxRmY,y,x,'n');
  }
  else if((mvinch(y-1,x) == ' ') &&( (y>maxRmY)|| dir == 0))
  {
    y--;
    mvprintw(y,x,"#");
    drawHallways(maxRmY,y,x,'s');
  }
  else if(mvinch(y,x+1) == ' ')
  {
    x++;
    mvprintw(y,x,"#");
    drawHallways(maxRmY,y,x,'w');
  }
  else if(mvinch(y,x-1) == ' ')
  {
    x--;
    mvprintw(y,x,"#");
    drawHallways(maxRmY,y,x,'e');
  }
  
             
}
void gameLoop(int curY, int curX, Enemy * enemies)
{
  char input;
  int flag;//indicator to exit games
  PlyrStruct playerStats; //stores the stats of the player
  createPlayer(&playerStats);
  statusUpdate(playerStats,curY,curX);
  flag = 0;

  input = getch();
  while((input != 'q') && (flag != 1))
  {
    statusUpdate(playerStats,curY,curX);
    useItem(input,curY, curX,&playerStats);
    moveChar(input, curY, curX, &playerStats, &flag,enemies);
    curY = getcury(stdscr);
    curX = getcurx(stdscr);
    moveEnemies(enemies,curY,curX);
    if(playerStats.curHp <= 0)
    {
      move(0,0);
      clrtoeol();
      mvprintw(0,0,"you died like the weakling you are");
      move(curY,curX);
      flag=1;
    }
    input = getch();
    statusUpdate(playerStats,curY,curX);
  }

  getch();
  endGame(playerStats);

}

void moveChar(char key, int curY, int curX, PlyrStruct * p, int * flag,Enemy * enemies)
{

  switch(key)
  {
    case 'a':
      updateScreen(curY, curX-1 , p, flag, enemies);
      break;

    case 'w':
      updateScreen(curY-1, curX, p , flag, enemies);
      break;

    case 's':
      updateScreen(curY +1, curX, p , flag, enemies);
      break;

    case 'd':
      updateScreen(curY, curX +1, p, flag, enemies);
      break;
  }
}

void updateScreen(int updateY, int updateX, PlyrStruct * p, int * flag, Enemy * enemies)
{
  int i;
  i = hitDetect(updateY, updateX, p, flag, enemies);
  if (i >= 1)  //altered from lab session, sorry about similarity if it is a problem, was the best way to do it i felt, also made another value it can detect
  {
    if(i ==2)
    {
      if(p->hallway%2 !=0)
      {
        printw(".");
      }
      else
      {
        printw("#");
      }
      p->doorFlag=1;
      
    }
    else
    {
      if(p->doorFlag==1)
      {
        p->doorFlag=0;
        printw("+");
      }
      else if((p->hallway)%2 !=0)
      {
        //p->doorFlag--;
        printw("#");
      }
      else
      {
        printw(".");
      }
    }

    mvprintw(updateY, updateX, "@");
    move(updateY, updateX);

  }
}

int hitDetect(int toGoY, int toGoX, PlyrStruct * p, int * flag, Enemy * enemies)
{
  int curX = getcurx(stdscr);
  int curY = getcury(stdscr);

  int r; //random temp

  char val = (char)mvinch(toGoY, toGoX);//gets character of the position wanting to move to
  move(curY, curX);
  if((val == '+'))
  {
    move(0,0);
    clrtoeol();
    mvprintw(0,0, "hero opened door\n");
    statusUpdate(*p,curY,curX);
    move(curY, curX);
    p->hallway++;
    return 2;
  }
  if((val == '>') || (val == '<'))
  {
    *flag =1;//tells the program to exit
  }
  if((val == '*'))//small gold
  {
    r = (rand()%50) +1;
    p->gold +=r;//update gold value
  }
  if((val == ']') ||(val == '(')||(val == ')')||(val == '!'))
  {
    move(0,0);
    clrtoeol();
    if(p->itemNum >=5)
    {
      mvprintw(0,0, "you broke the item %c\n",val);
    }
    if(p->itemNum <5)
    {
      switch (val) 
      {
        case ']':
          mvprintw(0,0, "Hero picked up equipment\n");
          r = (rand()%20);
          p->equipVal[p->itemNum] = r;
          p->bag[p->itemNum] = ']'; //puts the item in the bag and increases the itemNumber
          p->itemNum ++;
        break;
        
        case '(':
          mvprintw(0,0, "Hero picked up rare weapon\n");
          r = (rand()%5) +10;
          p->equipVal[p->itemNum] = r;
          p->bag[p->itemNum] = '(';
          p->itemNum ++;
        break;
        
        case ')':
          mvprintw(0,0, "Hero picked up a common weapon\n");
          r = (rand()%9) +1;
          p->equipVal[p->itemNum] = r;
          p->bag[p->itemNum] = ')';
          p->itemNum ++;
        break;
        
        case '!':
          mvprintw(0,0, "Hero picked up a potion\n");
          p->potionNum++;
        break;
        
      }
    }
    statusUpdate(*p,curY,curX);
    move(curY, curX);
    return 1;  
  }
  if((val == '8'))//big gold
  {
    r = (rand()%200) +50;
    p->gold += r;
  }
  if((val == 'Z') || (val == 'A') || (val == 'B') || (val == 'S') || (val == 'T'))
  {
    for(int i=0; i<50; i++)
    {
      if((enemies[i].x == toGoX) && (enemies[i].y == toGoY))//checks which enemy you are trying to attack
      {
        return combat(enemies, i, p,curY,curX);
      }
    }
  
  }
  if((val == '-') || (val == '|') || (val == ' '))
  {
    return 0;
  }
  move(0,0);
  clrtoeol();
  move(curY,curX);
  return 1;
}

void statusUpdate(PlyrStruct p, int y, int x)//need to get the player x and y before this is called
{
  int maxY;
  maxY = getmaxy(stdscr );
  mvprintw(maxY-1,0,"Health: %d/%d, Potions: %d, Attack: %d, Inv: %d/5", p.curHp,p.maxHp,p.potionNum,p.attack,p.itemNum);
  move(y,x);

}

void endGame(PlyrStruct p)
{
  int i;
  i=0;
  erase();
  mvprintw(3,3,"gold collected %d\n", p.gold);
  for(i=0; i<6;i++)
  {
    if(p.bag[i] != '\0')
    {
      printw("   "); //used for formating
      switch(p.bag[i])//prints out the values of the inventory
      {
        case ']':
          printw( "Hero picked up equipment, defence of: %d\n",p.equipVal[i]);
        break;
        case '(':
          printw("Hero picked up rare weapon, attack increase of: %d\n",p.equipVal[i]);
        break;
        case ')':
          printw("Hero picked up a common weapon, attack increase of: %d\n",p.equipVal[i]);
        break;
      }
    }

  }

  getch();
  endwin();

}

void createPlayer(PlyrStruct * p)
{
  p->maxHp = 50;
  p->curHp= 50;
  memset(p->bag,'\0',5);
  memset(p->equipVal, 0,5);
  p->potionNum=1;
  p->attack = 10;
  p->itemNum = 0;
  p->gold = 0;
  p->doorFlag = 0; //to keep track if the door was stepped on last
}
void createEnemy(Enemy * e, int index) //creates the enemies stats
{
  switch (e[index].desc)
  {
    case 'T':
      e[index].health = 50;
      e[index].attack = 5;
      e[index].speed = 3;
      e[index].moveNum = 0;
      strncpy(e[index].move,"nesw",4);
    break;
    case 'A':
      e[index].health = 5;
      e[index].attack = 1;
      e[index].speed = 2;
      e[index].moveNum = 0;
      strncpy(e[index].move,"0000",4); //doesnt move
    break;
    case 'B':
      e[index].health = 2;
      e[index].attack = 5;
      e[index].speed = 4;
      e[index].moveNum = 0;
      strncpy(e[index].move,"rrrr",4); //random
    break;
    case 'S':
      e[index].health = 5;
      e[index].attack = 5;
      e[index].speed = 4;
      e[index].moveNum = 0;
      strncpy(e[index].move,"eeww",4);
    break;
    case 'Z':
      e[index].health = 15;
      e[index].attack = 5;
      e[index].speed = 2;
      e[index].moveNum = 0;
      strncpy(e[index].move,"nsns",4);
    break;
  }
}
void useItem(char in,int curY,int curX,PlyrStruct * p)
{
  if(in == 'p')
  {
    if(p->potionNum > 0)
    {
      p->curHp = p->maxHp;
      p->potionNum --;
      move(0,0);
      clrtoeol();
      mvprintw(0,0,"used a potion and is now at full health");
      move(curY,curX);
      statusUpdate(*p,curY,curX);
    }
    else
    {
      move(0,0);
      clrtoeol();
      mvprintw(0,0,"no more potions");
      move(curY,curX);
    }
  }
}

int combat(Enemy * e, int index,PlyrStruct * p, int y, int x)
{
  int r;
  r = (rand()%10) +1;
  if(r>e[index].speed)//player attacks
  {
    e[index].health -= p->attack;
    if(e[index].health <= 0)
    {
      move(0,0);
      clrtoeol();
      mvprintw(0,0,"defeated enemy %c", e[index].desc);
      e[index].desc ='\0';
      move(y,x);
      return 1;
    }
    move(0,0);
    clrtoeol();
    mvprintw(0,0,"hit enemy, caused %d damage",p->attack);
    move(y,x);
    return 0;
    
  }
  else
  {
    if(e[index].desc == 'A') //aquator attack
    {
      p->attack -= e[index].attack;
      move(0,0);
      clrtoeol();
      mvprintw(0,0,"enemy hit you and rusted your armour, your attack drops by %d",e[index].attack);
      move(y,x);
    }
    else //everyone else's attack
    {
      p->curHp -= e[index].attack;
      move(0,0);
      clrtoeol();
      mvprintw(0,0,"enemy hit you and delt %d damage",e[index].attack);
      move(y,x);
    }
    return 0;
  }
  
}

void moveEnemies(Enemy * e, int y, int x)
{
  int r;
  for(int i =0; i<50;i++)
  {
    if(e[i].desc == 'T' ||e[i].desc == 'Z' ||e[i].desc == 'B' ||e[i].desc == 'A' ||e[i].desc == 'S')
    {
      if(e[i].move[e[i].moveNum] == 'r') //creates a random travel patrol for each bat (they will all move different from one another but in a pattern)
      {
        r = rand()%4;
        switch (r)
        {
          case 0:
            e[i].move[e[i].moveNum] = 'n';
          break;
          case 2:
            e[i].move[e[i].moveNum] = 'e';
          break;
          case 1:
            e[i].move[e[i].moveNum] = 's';
          break;
          case 3:
            e[i].move[e[i].moveNum] = 'w';
          break;
        }
      }
      switch (e[i].move[e[i].moveNum]) //loops through the patrol for the enemies, checks north south east west
      {
        case 'n':
          if((char)mvinch(e[i].y -1,e[i].x) == '.')//only moves if the spot over is a empty space
          {
            move(e[i].y,e[i].x);
            printw(".");
            mvprintw(e[i].y -1,e[i].x,"%c",e[i].desc);
            e[i].y = e[i].y-1;
          }
          e[i].moveNum ++;
          if(e[i].moveNum >=4)
          {
            e[i].moveNum=0;
          }
        break;
        case 's':
          if((char)mvinch(e[i].y +1,e[i].x) == '.')
          {
            move(e[i].y,e[i].x);
            printw(".");
            mvprintw(e[i].y +1,e[i].x,"%c",e[i].desc);
            e[i].y = e[i].y+1;
          }
          e[i].moveNum ++;
          if(e[i].moveNum >=4)
          {
            e[i].moveNum=0;
          }
        break;
        case 'e':
          if((char)mvinch(e[i].y,e[i].x +1) == '.')
          {
            move(e[i].y,e[i].x);
            printw(".");
            mvprintw(e[i].y ,e[i].x +1,"%c",e[i].desc);
            e[i].x = e[i].x+1;
          }
          e[i].moveNum ++;
          if(e[i].moveNum >=4)
          {
            e[i].moveNum=0;
          }
        break;
        case 'w':
          if((char)mvinch(e[i].y ,e[i].x -1) == '.')
          {
            move(e[i].y,e[i].x);
            printw(".");
            mvprintw(e[i].y ,e[i].x -1,"%c",e[i].desc);
            e[i].x = e[i].x-1;
          }
          e[i].moveNum ++;
          if(e[i].moveNum >=4)
          {
            e[i].moveNum=0;
          }
        break;
        
      }
    }
  }
  move(y,x);//move back to the hero position    
  
  
  
  
  
  
} //mwahahahahahahahaha!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
