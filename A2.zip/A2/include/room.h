#ifndef __NLEIPOLD_ROOM_H__
#define __NLEIPOLD_ROOM_H__

/*struct ItemLocation
 *stores the positions of the items
 *maximum of 10 items in room
 *larger array to account for precoious instructions
 */
struct itemLocation
{
  char desc[15];
  int y[15];
  int x[15];
  int numInst;
  int numRoom;
};
typedef struct itemLocation ItLoc;


/* parceFile
 * calls the desired functions needed to open the roomtemplate files and get data for the room designs
 * IN: argv[]
 * OUT: item and room struct
 * ERROR: no known errors
 */
ItLoc * parceFile(char * filePath);

/* sortDirections
 * splits each line of the template file into the seperate commands
 * IN: file stream pointer
 * OUT: sends parts of the directions to the storeRoom() function, returns item and room struct
 * ERROR: no known errors
 * LIMITATIONS: lines in file must be less than 256 characters
 */
ItLoc * sortDirections( FILE * stream);

/* storeRoom
 *sorts the instructions to be dealt with my the proper functions
 * IN: a string of current instruction, instruction number, pointer to item struct 
 * OUT: --------------------------------
 * ERROR: ---------------------------
 */
void storeRoom(char * specs, int instructIndex, ItLoc * items);

/* getPosIt
 * IN: item string, item number, item struct pointer, string index
 * OUT: creates values in struct where the items will be placed
 * ERROR:
 */
void getPosIt(char * str, int itNum,ItLoc * items,  int * strIndex);

/*getPosDr
 *IN: door string, item number, item struct pointer, string index
 *OUT: creates values in struct for the location of the door
 *ERROR: ____________________-
 */

void getPosDr(char * str,int drNum, ItLoc * doors, int * i);



#endif
