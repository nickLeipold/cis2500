#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "openFile.h"
#include "room.h"


ItLoc * parceFile(char * filePath)
{
  ItLoc * items;
  FILE * fileStream;
  fileStream = openStream(filePath);
  items = sortDirections(fileStream);
  closeStream(fileStream);
  srand(time(NULL));//starts timer to create random value
  
  
  return items;
}

ItLoc * sortDirections( FILE * stream)
{
  char line[256];
  int i;
  char temp[256];
  int roomNum;
  int instructNum;
  ItLoc * items = malloc(sizeof(ItLoc)*6);

  for(i=0;i<6;i++)//creates struct to go with the struct pointer for each room
  {
    ItLoc roomItem = {"i"}; 
    items[i]= roomItem;
  }

  roomNum = 0;
  instructNum=0;

  //printf("in sortDirections function\n");

  while(fgets(line,256, stream) != NULL)
  {
    int movingStart;
    movingStart=0;

    for(i=0 ; i<= strlen(line); i++)
    {
      if(line[i] == ' ' || line[i] =='\n')
      {
        memset(temp, '\0',256);//clear the temp file

        strncpy(temp, line+movingStart, i-movingStart);//print to another string each part of the room intructions
        //printf("%s \n",temp);
        storeRoom(temp, instructNum, &items[roomNum]);//send the room number and the draw instruction to be stored, along with the instruction number and the structs for the doors and the items
        i++;
        movingStart = i;//holds the location of where they are in the line
        instructNum++;
       }
     }
     items[roomNum].numInst = instructNum;
     instructNum =0;
     roomNum++;//shows what room the data goes with
  }
  items[0].numRoom = roomNum-1;
  
  return items;
}


/* storeRoom
 * IN: the different instructions, the instruction number, the struct to be stored in
 * OUT: stored items in the struct
 * ERROR:
 */ 
void storeRoom(char * specs, int instIndex, ItLoc * items)
{
  int i;
  i=0;



  if(instIndex == 0)
  {
    char * floorY;
    char * floorX;
    
    floorY = strtok(specs, "X");
    floorX = strtok(NULL, " ");
    (*items).desc[instIndex] = 'X';//whenever the size of the board is given the struct gets X as desc
    (*items).x[instIndex] =atoi(floorX); //gives the floor column number
    (*items).y[instIndex] =atoi(floorY); //gives the floor row number

  }
  
  if(instIndex != 0)
  {
    int r;
    for( i=0; i<strlen(specs) ; i++)
    {

      switch (specs[i])
      {
        case 'd':  //door

          getPosDr(specs,instIndex,items,&i);
          break;

        case 'h':  //hero
          (*items).desc[instIndex] = '@';
          getPosIt(specs, instIndex, items, &i);
          //printf("found hero\n"); //error checking
          break;

        case 'z':  //strairs going down
          //printf("found stairsdown\n"); //error checking
          (*items).desc[instIndex] = '<';
          getPosIt(specs, instIndex, items, &i);
          
          break;

        case 'a':  //stairs going up
          //printf("found stairsup\n"); //error checking
          (*items).desc[instIndex] = '>';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'g':  //small gold (0-50)
          //printf("found small gold     room %d\n", roomIndex); //error checking
          (*items).desc[instIndex] = '*';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'G':  //big gold (50 -250)
          //printf("found big gold\n"); //error checking
          (*items).desc[instIndex] = '8';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'w':  //common weapon
          //printf("found weapon\n"); //error checking
          (*items).desc[instIndex] = ')';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'W':  //Rare weapon
          (*items).desc[instIndex] = '(';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'm':  //weak monster (random)
          
          
          r = rand() %4;
          if(r == 0)  //chooses a random monster to be placed
          {
            (*items).desc[instIndex] = 'A';
          }
          if(r ==1)
          {
            (*items).desc[instIndex] = 'B';
          }
          if(r == 2)
          {
            (*items).desc[instIndex] = 'S';
          }
          if(r == 3)
          {
            (*items).desc[instIndex] = 'Z';
          } 
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'e':  //equipment
          (*items).desc[instIndex] = ']';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'M':  //strong monster
          (*items).desc[instIndex] = 'T';
          getPosIt(specs, instIndex, items, &i);
          break;

        case 'p':  //potion
          (*items).desc[instIndex] = '!';
          getPosIt(specs, instIndex, items, &i);
          break;
      }

    }
  }


}

void getPosIt(char * str, int itNum,ItLoc * items, int * strIndex)
{
  char temp[3];
  int j;
  int z;
  j = 0;
  z=0;
  (*strIndex)++;
  

  memset(temp,'\0',3);

  while(str[*strIndex] != ',')  //separates instructions at the comma
  {
    
    temp[j] = str[*strIndex];
    j++;
    (*strIndex)++;
  }

  (*strIndex)++;
  z = (int)atoi(temp);
  (*items).y[itNum] = z;
  memset(temp, '\0',3);

  j=0;
  while( (*strIndex) <= strlen(str))
  {
    temp[j] = str[*strIndex];
    j++;
    (*strIndex)++;
  }
  (*items).x[itNum]= atoi(temp);


}

void getPosDr(char * str,int drNum, ItLoc * doors,int * i)
{
  char temp[3];
  int j;
  j=0;
  (*doors).desc[drNum]= '+';
  *i = 2;


  while(*i<= strlen(str)) //copies back part of the string
  {
    temp[j] = str[*i];
    j++;
    (*i)++;
  }
  j = atoi(temp);//converts the words to integers (word nums to num nums)

  if( str[1] == 'e')  //takes the direction and then creates where the door should be
  {
    (*doors).x[drNum] = 99;
    (*doors).y[drNum]= j;
  }
  else if(str[1] == 'n')
  {
    (*doors).y[drNum] = -1;
    (*doors).x[drNum]= j;
  }
  else if(str[1] == 'w')
  {
    (*doors).x[drNum] = -1;
    (*doors).y[drNum]= j;
  }
  else if(str[1] == 's')
  {
    (*doors).y[drNum] = 99; //use 99 so when drawing later to auto move it
    (*doors).x[drNum]= j;
  }


}


