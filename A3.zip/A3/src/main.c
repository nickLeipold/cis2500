#include <stdlib.h>
#include <stdio.h>
#include "room.h" //the room file that will parce the room
#include "game.h" // draws the room and the game events run

int main(int argc, char * argv[])
{
  if(argc != 2) //if there are not two arguments close the program
  {
    printf("incorrect number of arguments\n");
    return 1;
  }
  ItLoc * items; //creates an item struct pointer
  items = parceFile(argv[1]); // the item struct is equal to the rooms passed back from parce
  drawRooms(items); // jumps into the game function and draws the room then the rest of the game continues in that file

  return 0;
}
