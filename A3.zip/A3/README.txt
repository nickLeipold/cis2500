Welcome to the School of Computer Science GIT

In order to make using GIT easier for users acustomed to SVN, the following chart with SVN and GIT commands has been provided.

SVN/GIT Command Chart:

SVN Command		| GIT Command
========================|==========================
svn checkout		| git clone
svn update		| git pull
svn add file		| git add file
svn commit		| git commit -a followed by git push
